package com.quartetofantastico.emoesc.world;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.quartetofantastico.emoesc.logicAndMechanic.Constants;
import com.quartetofantastico.emoesc.logicAndMechanic.Entity;

public class Avatar extends Entity {
    private float invencibilidade = 0f;
    Constants CONST = new Constants();
    private String name;
    private int id, health;
    float tamanho;
    float olhoTamanho;
    float speed = 200.0f;  // pixels/segundo
    int dirX = 0, dirY = 0;
    public Array entities = new Array<>();
    public Array<Rectangle> walls = new Array<>();

    public Avatar(String _name, Vector2 _position) {
        super(_position, 0.8f * Constants.SCALE, 0.8f * Constants.SCALE);
        tamanho = 0.8f * Constants.SCALE;
        olhoTamanho = 0.1f * Constants.SCALE;
        this.name = _name;
        this.health = 100;
        bounds = new Rectangle(_position.x, _position.y, tamanho, tamanho);
    }

    @Override
    public void draw(ShapeRenderer _draw) {
        // Corpo quadrado (vista de cima)
        _draw.setColor(CONST.GREEN_COLOR);
        _draw.rect(position.x, position.y, tamanho, tamanho);

        // Olhos virados para direção
        _draw.setColor(CONST.WHITE_COLOR);
        float eyeOffsetX = (dirX == 0 ? 0 : dirX * 0.15f * CONST.SCALE);
        float eyeOffsetY = (dirY == 0 ? 0 : dirY * 0.15f * CONST.SCALE);

        float eyeCenterX = position.x + (tamanho / 2);
        float eyeCenterY = position.y + (tamanho / 2);

        _draw.circle(eyeCenterX - 0.15f * CONST.SCALE + eyeOffsetX,
            eyeCenterY + 0.1f * CONST.SCALE + eyeOffsetY,
            olhoTamanho);
        _draw.circle(eyeCenterX + 0.15f * CONST.SCALE + eyeOffsetX,
            eyeCenterY + 0.1f * CONST.SCALE + eyeOffsetY,
            olhoTamanho);
    }

    @Override
    public void update(float delta) {
        if (invencibilidade > 0) invencibilidade -= delta;

        // Lê entrada
        dirX = 0;
        dirY = 0;
        if (CONST.UP_KEY())    dirY = 1;
        if (CONST.DOWN_KEY())  dirY = -1;
        if (CONST.LEFT_KEY())  dirX = -1;
        if (CONST.RIGHT_KEY()) dirX = 1;

        // Aplica movimento com colisão
        moveTopDown(dirX * speed * delta, dirY * speed * delta, entities);
    }

    /**
     * Movimento 2D vista de cima com colisão separada por eixo (evita travamento em cantos)
     */
    public void moveTopDown(float nextDeltaX, float nextDeltaY, Array<Entity> entities) {
        Array<Entity> targetEntities = (entities != null) ? entities : this.entities;

        // --- Movimento no EIXO X (esquerda/direita) ---
        if (nextDeltaX != 0) {
            float nextX = MathUtils.clamp(
                position.x + nextDeltaX,
                0,
                Constants.W_WORLD_SIZE - tamanho
            );

            Rectangle nextBoundsX = new Rectangle(nextX, position.y, tamanho, tamanho);

            // Verifica colisão com paredes
            boolean colideX = false;
            for (Rectangle wall : walls) {
                if (nextBoundsX.overlaps(wall)) {
                    colideX = true;
                    break;
                }
            }

            // Verifica colisão com entidades
            if (!colideX && !collides(nextX, position.y, targetEntities)) {
                position.x = nextX;
            }
        }

        // --- Movimento no EIXO Y (cima/baixo) ---
        if (nextDeltaY != 0) {
            float nextY = MathUtils.clamp(
                position.y + nextDeltaY,
                0,
                Constants.H_WORLD_SIZE - tamanho
            );

            Rectangle nextBoundsY = new Rectangle(position.x, nextY, tamanho, tamanho);

            // Verifica colisão com paredes
            boolean colideY = false;
            for (Rectangle wall : walls) {
                if (nextBoundsY.overlaps(wall)) {
                    colideY = true;
                    break;
                }
            }

            // Verifica colisão com entidades
            if (!colideY && !collides(position.x, nextY, targetEntities)) {
                position.y = nextY;
            }
        }

        updateBounds();
    }

    @Override
    public void updateBounds() {
        bounds.setPosition(position.x, position.y);
    }

    // Getters/Setters
    public String getName() { return name; }
    public int getHealth() { return health; }

    public void decreaseHealth(int damage) {
        if (podeTomarDano()) {
            health -= damage;
            if (health < CONST.MIN_HEALTH) health = CONST.MIN_HEALTH;
            ativarInvencibilidade();
        }
    }

    public void increaseHealth(int help) {
        health += help;
        if (health > CONST.MAX_HEALTH) health = CONST.MAX_HEALTH;
    }

    public void increaseSpeed(int _speed) { this.speed += _speed; }
    public void decreaseSpeed(int _speed) { this.speed -= _speed; }

    public boolean podeTomarDano() {
        return invencibilidade <= 0;
    }

    public void ativarInvencibilidade() {
        invencibilidade = 1.0f;
    }
}
